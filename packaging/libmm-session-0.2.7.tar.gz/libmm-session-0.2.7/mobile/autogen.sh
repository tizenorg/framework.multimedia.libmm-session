aclocal
libtoolize --copy
autoheader
autoconf
automake --add-missing --copy --foreign
